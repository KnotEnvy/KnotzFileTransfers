document.getElementById('login-form').addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent default form submission

    // Retrieve user input
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;

    // Hardcoded credentials
    var adminUsername = 'admin';
    var adminPassword = 'password';

    // Validate credentials
    if (username === adminUsername && password === adminPassword) {
        // Hide login section
        document.getElementById('login').style.display = 'none';

        // Show dashboard
        document.getElementById('dashboard').classList.remove('hidden');

        // Navigate to the dashboard (optional)
        window.location.hash = 'dashboard';
    } else {
        // Display error message (you can customize this as needed)
        var errorMessage = "Invalid username or password";
        if (!username) errorMessage = "Username is required";
        if (!password) errorMessage = "Password is required";

        // Display the error message
        alert(errorMessage);
    }
});
